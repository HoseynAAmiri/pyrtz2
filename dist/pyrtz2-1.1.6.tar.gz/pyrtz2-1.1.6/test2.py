from pyrtz2 import app

app.run()
