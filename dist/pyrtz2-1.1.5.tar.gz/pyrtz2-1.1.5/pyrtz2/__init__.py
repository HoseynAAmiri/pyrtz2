"""Force spectroscopy in Python"""

__version__ = "1.1.5"
