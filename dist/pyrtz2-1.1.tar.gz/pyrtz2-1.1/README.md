# pyrtz2

Analysis of AFM force curves in Python.

Developed at Georgia Institute of Technology

# Installation
pyrtz2 is on PyPI. Install using pip (Python version >= 3.11.0 is required)

```
pip install pyrtz2
```
